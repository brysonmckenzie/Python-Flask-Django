# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect, HttpResponse

from .models import User,Task

from datetime import datetime



def index(request): #mainpage

    current_user = User.objects.get(id = 1)

    context = {
        'users':User.objects.all(),
        'tasks':Task.objects.filter(user_id = current_user.id),
        # 'task_today':Task.objects.filter(date=datetime.today(), user_id)
        
    }
    



    return render(request,'appointment_app/index.html', context)

def login (request): #login page

    return render(request, 'appointment_app/login.html')


def register(request):  #registration page

    return render(request,'appointment_app/registration.html')

def show_update(request,id):
    
    context = {
    'task':Task.objects.get(id = id),
    }

    return render(request,'appointment_app/update.html',context)



def add_task(request):
    
    server_task = request.POST['html_task']
    server_time = request.POST['html_time']
    server_date = request.POST['html_date']

    user = User.objects.get(id = 2)

 
    Task.objects.create(task = server_task, time = server_time, date = server_date, status = False, user_id = user.id)
    

    return redirect('/')

# def edit(request):

#     return redirect('/')

# def delete(request):
    

#     return redirect('/')

def update_process(request):
    
    server_task = request.POST['html_task']
    server_time = request.POST['html_time']
    server_date = request.POST['html_date']
    server_status = request.POST['html_status']
    
    task = Task.objects.get(id = id)

    task.update(task = server_task, status = server_status, date = server_date, time = server_time) 

    return redirect('/')


def register_process(request): #registration_process

    server_firstname = request.POST['html_firstname']
    server_lastname = request.POST['html_lastname']
    server_email = request.POST['html_email']
    server_birthday = request.POST['html_birthday']
    server_password = request.POST['html_password']
    print request.POST,"<********************************"


    User.objects.create(
        first_name = server_firstname,
        last_name = server_lastname,
        email = server_email,
        password = server_password,
        birthday = server_birthday,
    )
    print '****************New User*********************'

    return redirect('/login_page')
    


def login_process(request): #login process
    
    user = User.objects.get(email = request.POST['html_email'])
    if request.POST['html_email'] == user.password:
        
        request.session['user_id'] = user.id
        print "********** User Logged IN**************"
        print "**** User ID = "+ str(user.id) + " *** ID IN SESSIONS ***" 
        print "The user #" + str(user.id) + "has now logged in the system" 
        print "***************************************"


        
        
    return redirect('/')



def logout(request): #log out function

    request.session.clear()

    return redirect('/login')